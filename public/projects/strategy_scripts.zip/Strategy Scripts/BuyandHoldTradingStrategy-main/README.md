# BuyandHoldTradingStrategy

Simply buying and holding each selected asset with an equal weighting that is inputted into the strat. This is achived by first defining a pandas dataframe full of ones and then dividing through by the number of tickers (or codes). 

Although this isn't much of an algorithm, it is useful for seeing how the skeleton code (Strategies class) works.

Look at my other algorithms for the application of this class to more complex strategies.
